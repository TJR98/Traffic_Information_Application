/*
 * Name: Todor Joseph Radic
 * Student ID / Matriculation Number: S1620373
 */

package org.me.gcu.mpd.newtrafficapp;

import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.Locale;

public class SearchDateResultsPage extends Fragment {

    private View view;

    URL aurl;
    URLConnection conn;
    BufferedReader br;
    String in;

    private String urlSourceText;
    private String userDateInputText;
    private long userInputDateTimeMilliSeconds;
    private long startDateTimeMilliSeconds;
    private long endDateTimeMilliSeconds;
    private String result;

    private LinkedList<TrafficData> dataList;
    private TrafficData data;

    public SearchDateResultsPage(String urlSource, String userDateInput) {

        urlSourceText = urlSource;
        userDateInputText = userDateInput;
        Task t = new Task();
        t.execute(urlSource);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_search_page, container, false);
        return view;
    }

    private class Task extends AsyncTask<String, String, LinkedList<TrafficData>> implements Runnable {

        private StringBuilder resultSB = new StringBuilder();

        @Override
        protected LinkedList<TrafficData> doInBackground(String... urlSource) {

            try {
                aurl = new URL(urlSource[0]);
                conn = aurl.openConnection();
                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                while ((in = br.readLine()) != null) {
                    resultSB.append(in);
                }
                br.close();
                result = resultSB.toString();
                dataList = parseData(result);
            } catch (IOException ae) {
                ae.getCause();
            }
            return dataList;
        }

        @Override
        protected void onPostExecute(LinkedList<TrafficData> dataList) {
            try {
                super.onPostExecute(dataList);

                TextView headingSearchTextView = view.findViewById(R.id.headingSearchText);

                switch (urlSourceText) {
                    case "https://trafficscotland.org/rss/feeds/roadworks.aspx":
                        headingSearchTextView.setText(getString(R.string.roadworks_heading, Integer.toString(dataList.size())));
                        break;
                    case "https://trafficscotland.org/rss/feeds/plannedroadworks.aspx":
                        headingSearchTextView.setText(getString(R.string.planned_roadworks_heading, Integer.toString(dataList.size())));
                        break;
                    case "https://trafficscotland.org/rss/feeds/currentincidents.aspx":
                        headingSearchTextView.setText(getString(R.string.current_incidents_heading, Integer.toString(dataList.size())));
                }

                LinearLayout mainLinearLayout = view.findViewById(R.id.searchResultsPage);

                for (int i = 0; i < dataList.size(); i++) {
                    LinearLayout newOuterLinearLayout = new LinearLayout(getActivity());
                    newOuterLinearLayout.setId(i);
                    newOuterLinearLayout.setOrientation(LinearLayout.VERTICAL);
                    newOuterLinearLayout.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
                    GradientDrawable border = new GradientDrawable();
                    border.setColor(0xFFFFFFFF); //white background
                    border.setStroke(1, 0xFF000000); //black border with full opacity
                    newOuterLinearLayout.setBackground(border);

                    TextView textViewTitleText = new TextView(getActivity());
                    textViewTitleText.setId(i);
                    textViewTitleText.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
                    LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                    params.gravity = Gravity.CENTER;
                    textViewTitleText.setLayoutParams(params);
                    textViewTitleText.setText(dataList.get(i).getTitle());
                    textViewTitleText.append(System.getProperty("line.separator"));

                    newOuterLinearLayout.addView(textViewTitleText);

                    TextView textViewStartDateText = new TextView(getActivity());
                    textViewStartDateText.setId(i);
                    textViewStartDateText.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
                    textViewStartDateText.setText(getString(R.string.start_date_text, dataList.get(i).getStartDate()));
                    textViewStartDateText.append(System.getProperty("line.separator"));

                    newOuterLinearLayout.addView(textViewStartDateText);

                    TextView textViewEndDateText = new TextView(getActivity());
                    textViewEndDateText.setId(i);
                    textViewEndDateText.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
                    textViewEndDateText.setText(getString(R.string.end_date_text, dataList.get(i).getEndDate()));
                    textViewEndDateText.append(System.getProperty("line.separator"));

                    newOuterLinearLayout.addView(textViewEndDateText);

                    mainLinearLayout.addView(newOuterLinearLayout);

                }
            } catch (Exception e) {
                e.getStackTrace();
            }
        }

        @Override
        public void run() {

        }

        public LinkedList<TrafficData> parseData(String dataToParse) {
            try {
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser xpp = factory.newPullParser();
                xpp.setInput(new StringReader(dataToParse));
                int eventType = xpp.getEventType();
                while (eventType != XmlPullParser.END_DOCUMENT) {
                    // Found a start tag
                    if (eventType == XmlPullParser.START_TAG) {
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("channel")) {
                            dataList = new LinkedList<>();
                        } else
                            // Check which Tag we have
                            if (xpp.getName().equalsIgnoreCase("item")) {
                                data = new TrafficData();
                            }
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("title") && data != null) {
                            // Now just get the associated text
                            String temp = xpp.nextText();
                            // Do something with text
                            data.setTitle(temp);
                        }
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("description") && data != null) {
                            // Now just get the associated text
                            String temp = xpp.nextText();
                            // Do something with text
                            String startDate = data.extractStartDateWithDay(temp);
                            String endDate = data.extractEndDateWithDay(temp);
                            data.setStartDate(startDate);
                            data.setEndDate(endDate);

                            String startDateTimeString = data.extractStartDate(temp);
                            String endDateTimeString = data.extractEndDate(temp);
                            DateFormat df = new SimpleDateFormat("dd MMMM yyyy", Locale.ENGLISH);
                            Date userInputDateTime = df.parse(userDateInputText);
                            Date startDateTime = df.parse(startDateTimeString);
                            Date endDateTime = df.parse(endDateTimeString);
                            assert userInputDateTime != null;
                            userInputDateTimeMilliSeconds = userInputDateTime.getTime();
                            assert startDateTime != null;
                            startDateTimeMilliSeconds = startDateTime.getTime();
                            assert endDateTime != null;
                            endDateTimeMilliSeconds = endDateTime.getTime();
                        }
                    } else if (eventType == XmlPullParser.END_TAG) {
                        if (xpp.getName().equalsIgnoreCase("item") && isWithinDate()) {
                            dataList.add(data);
                        }
                    }
                    // Get the next event
                    eventType = xpp.next();
                } // End of while
            } catch (XmlPullParserException | IOException | ParseException e) {
                e.printStackTrace();
            }
            return dataList;
        }

        private boolean isWithinDate() {

            boolean b;

            b = userInputDateTimeMilliSeconds > startDateTimeMilliSeconds && userInputDateTimeMilliSeconds < endDateTimeMilliSeconds;
            return b;
        }

    }

}
