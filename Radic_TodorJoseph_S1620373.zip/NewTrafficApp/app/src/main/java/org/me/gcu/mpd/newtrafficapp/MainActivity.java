/*
 * Name: Todor Joseph Radic
 * Student ID / Matriculation Number: S1620373
 */

package org.me.gcu.mpd.newtrafficapp;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.Activity;
import android.os.Bundle;

import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends FragmentActivity implements OnClickListener, OnItemSelectedListener
{
    // Views
    private Spinner navigationMenu;
    private Spinner searchOptionsMenu;
    private EditText searchRoadInput;
    private Button searchRoadButton;
    private EditText searchDateInput;
    private Button searchDateButton;

    // Traffic app fragment pages
    private Fragment frHome;
    private Fragment frNavigationOption;
    private Fragment frSearchTitleResults;
    private Fragment frSearchDateResults;
    private Fragment frPage;

    // Traffic Scotland URLs
    private String urlSource;
    private String roadworksURL = "https://trafficscotland.org/rss/feeds/roadworks.aspx";
    private String plannedRoadworksURL = "https://trafficscotland.org/rss/feeds/plannedroadworks.aspx";
    private String currentIncidentsURL = "https://trafficscotland.org/rss/feeds/currentincidents.aspx";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initiate code for applying instructions for each specific view
        navigationMenu = findViewById(R.id.navigationMenu);
        searchOptionsMenu = findViewById(R.id.searchOptionsMenu);
        searchRoadInput = findViewById(R.id.searchRoadInput);

        // Hides keyboard when user clicks outside the EditText box
        searchRoadInput.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });
        searchRoadButton = findViewById(R.id.searchRoadButton);
        searchRoadButton.setOnClickListener(this);
        searchDateInput = findViewById(R.id.searchDateInput);
        searchDateInput.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });
        searchDateButton = findViewById(R.id.searchDateButton);
        searchDateButton.setOnClickListener(this);

        // Sets initial fragment page to the HomePage fragment
        frHome = new HomePage();

        // Sets the spinner to the default design with the options specified in the string array of the strings.xml file
        ArrayAdapter navigationMenuAdapter = ArrayAdapter.createFromResource(
                this, R.array.navigation_menu_options, android.R.layout.simple_spinner_item);
        navigationMenuAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        navigationMenu.setAdapter(navigationMenuAdapter);
        navigationMenu.setOnItemSelectedListener(this);

        ArrayAdapter searchOptionsMenuAdapter = ArrayAdapter.createFromResource(
                this, R.array.search_menu_options, android.R.layout.simple_spinner_item);
        searchOptionsMenuAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        searchOptionsMenu.setAdapter(searchOptionsMenuAdapter);
        searchOptionsMenu.setOnItemSelectedListener(this);

        getSupportFragmentManager().beginTransaction().add(R.id.fragment, frHome).commit();

    }

    public void hideKeyboard(View v) {
        InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(Activity.INPUT_METHOD_SERVICE);
        assert inputMethodManager != null;
        inputMethodManager.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    public void onClick(View v)
    {
        if (v == searchRoadButton)
        {
            String text = searchRoadInput.getText().toString();
            frSearchTitleResults = new SearchTitleResultsPage(urlSource, text);
            frPage = frSearchTitleResults;
        } else {
            if (v == searchDateButton)
            {
                //text
                String text = searchDateInput.getText().toString();
                frSearchDateResults = new SearchDateResultsPage(urlSource, text);
                frPage = frSearchDateResults;
            }
        }
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.fragment,frPage);
        transaction.commit();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (parent == navigationMenu)
        {
            String text = (String)navigationMenu.getSelectedItem();

            switch (text) {
                case "HOME":
                    frPage = new HomePage();
                    break;
                case "ROADWORKS":
                    urlSource = roadworksURL;
                    frNavigationOption = new NavigationOptionPage(urlSource);
                    frPage = frNavigationOption;
                    break;
                case "PLANNED ROADWORKS":
                    urlSource = plannedRoadworksURL;
                    frNavigationOption = new NavigationOptionPage(urlSource);
                    frPage = frNavigationOption;
                    break;
                case "CURRENT INCIDENTS":
                    urlSource = currentIncidentsURL;
                    frNavigationOption = new NavigationOptionPage(urlSource);
                    frPage = frNavigationOption;
                    break;
                case "MAP":
                    frPage = new MapPage(urlSource);
            }
        } else {
            if (parent == searchOptionsMenu)
            {
                String text = (String)searchOptionsMenu.getSelectedItem();

                switch (text)
                {
                    case "ROADWORKS":
                        urlSource = roadworksURL;
                        break;
                    case "PLANNED ROADWORKS":
                        urlSource = plannedRoadworksURL;
                        break;
                    case "CURRENT INCIDENTS":
                        urlSource = currentIncidentsURL;
                }
            }
        }
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.fragment,frPage);
        transaction.commit();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
} // End of MainActivity