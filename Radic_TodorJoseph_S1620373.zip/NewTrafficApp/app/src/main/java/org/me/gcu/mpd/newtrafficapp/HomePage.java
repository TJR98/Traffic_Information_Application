/*
 * Name: Todor Joseph Radic
 * Student ID / Matriculation Number: S1620373
 */

package org.me.gcu.mpd.newtrafficapp;

import androidx.fragment.app.Fragment;

public class HomePage extends Fragment {

    public HomePage()
    {
        //text
    }
}
