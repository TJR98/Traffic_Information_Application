/*
 * Name: Todor Joseph Radic
 * Student ID / Matriculation Number: S1620373
 */

package org.me.gcu.mpd.newtrafficapp;

public class TrafficData {

    private String title;
    private String startDate;
    private String endDate;
    private double latitude;
    private double longitude;

    public TrafficData()
    {
        title = "";
        startDate = "";
        endDate = "";
        latitude = 0.0;
        longitude = 0.0;
    }

    public TrafficData(String aTitle, String aStartDate, String aEndDate, double aLatitude, double aLongitude)
    {
        title = aTitle;
        startDate = aStartDate;
        endDate = aEndDate;
        latitude = aLatitude;
        longitude = aLongitude;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String aTitle)
    {
        title = aTitle;
    }

    public String getStartDate()
    {
        return startDate;
    }

    public void setStartDate(String aStartDate)
    {
        startDate = aStartDate;
    }

    public String extractStartDateWithDay(String temp)
    {
        String[] extractedStartDateText = temp.split(" ");
        return extractedStartDateText[2] + " " + extractedStartDateText[3] + " " + extractedStartDateText[4] + " " + extractedStartDateText[5];
    }

    public String extractStartDate(String temp)
    {
        String[] extractedStartDateText = temp.split(" ");
        return extractedStartDateText[3] + " " + extractedStartDateText[4] + " " + extractedStartDateText[5];
    }

    public String getEndDate()
    {
        return endDate;
    }

    public void setEndDate(String aEndDate)
    {
        endDate = aEndDate;
    }

    public String extractEndDateWithDay(String temp)
    {
        String[] extractedEndDateText = temp.split(" ");
        return extractedEndDateText[10] + " " + extractedEndDateText[11] + " " + extractedEndDateText[12] + " " + extractedEndDateText[13];
    }

    public String extractEndDate(String temp)
    {
        String[] extractedEndDateText = temp.split(" ");
        return extractedEndDateText[11] + " " + extractedEndDateText[12] + " " + extractedEndDateText[13];
    }

    public double getLatitude()
    {
        return latitude;
    }

    public void setLatitude(double aLatitude)
    {
        latitude = aLatitude;
    }

    public double extractLatitude(String temp)
    {
        String[] extractedLatitude = temp.split(" ");
        return Double.parseDouble(extractedLatitude[0]);
    }

    public double getLongitude()
    {
        return longitude;
    }

    public void setLongitude(double aLongitude)
    {
        longitude = aLongitude;
    }

    public double extractLongitude(String temp)
    {
        String[] extractedLongitude = temp.split(" ");
        return Double.parseDouble(extractedLongitude[1]);
    }

    public String toString()
    {
        String temp;

        temp = title + ", " + startDate + ", " + endDate + ", " + latitude + ", " + longitude;

        return temp;
    }
}