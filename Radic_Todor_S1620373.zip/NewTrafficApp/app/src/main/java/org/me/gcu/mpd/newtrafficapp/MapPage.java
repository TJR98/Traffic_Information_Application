/*
 * Name: Todor Joseph Radic
 * Student ID / Matriculation Number: S1620373
 */

package org.me.gcu.mpd.newtrafficapp;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.LinkedList;

public class MapPage extends Fragment implements OnMapReadyCallback {

    URL aurl;
    URLConnection conn;
    BufferedReader br;
    String in;

    private String result;

    private MapView mMapView;
    private GoogleMap mGoogleMap;
    private View mView;

    private LinkedList<TrafficData> dataList;
    private TrafficData data;

    public MapPage(String urlSource) {

        Task t = new Task();
        t.execute(urlSource);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_map_page, container, false);

        return mView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState)
    {
        super.onViewCreated(view, savedInstanceState);

        mMapView = mView.findViewById(R.id.map);
        if (mMapView != null)
        {
            mMapView.onCreate(null);
            mMapView.onResume();
            mMapView.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        MapsInitializer.initialize(getContext());

        mGoogleMap = googleMap;
        googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng( 55.860916, -4.251433), 7));

    }

    private class Task extends AsyncTask<String, String, LinkedList<TrafficData>> implements Runnable {

        private StringBuilder resultSB = new StringBuilder();

        @Override
        protected LinkedList<TrafficData> doInBackground(String... urlSource) {

            try {
                aurl = new URL(urlSource[0]);
                conn = aurl.openConnection();
                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                while ((in = br.readLine()) != null) {
                    resultSB.append(in);
                }
                br.close();
                result = resultSB.toString();
                dataList = parseData(result);
            } catch (IOException ae) {
                ae.getCause();
            }
            return dataList;
        }

        @Override
        protected void onPostExecute(LinkedList<TrafficData> dataList) {
            try {
                super.onPostExecute(dataList);

                for (int i = 0; i < dataList.size() ; i++)
                {
                    mGoogleMap.addMarker(new MarkerOptions().position(new LatLng(dataList.get(i).getLatitude(), dataList.get(i).getLongitude())).title(dataList.get(i).getTitle()).snippet("Start Date: " + dataList.get(i).getStartDate() + "\n" + "End Date: " + dataList.get(i).getEndDate()));

                    mGoogleMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {

                        @Override
                        public View getInfoWindow(Marker arg0) {
                            return null;
                        }

                        @Override
                        public View getInfoContents(Marker marker) {

                            LinearLayout info = new LinearLayout(getContext());
                            info.setOrientation(LinearLayout.VERTICAL);

                            TextView title = new TextView(getContext());
                            title.setTextColor(Color.BLACK);
                            title.setGravity(Gravity.CENTER);
                            title.setTypeface(null, Typeface.BOLD);
                            title.setText(marker.getTitle());

                            TextView snippet = new TextView(getContext());
                            snippet.setTextColor(Color.GRAY);
                            snippet.setText(marker.getSnippet());

                            info.addView(title);
                            info.addView(snippet);

                            return info;
                        }
                    });

                }
            } catch (Exception e) {
                e.getStackTrace();
            }
        }

        @Override
        public void run() {

        }

        public LinkedList<TrafficData> parseData(String dataToParse)
        {
            try
            {
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser xpp = factory.newPullParser();
                xpp.setInput( new StringReader( dataToParse ) );
                int eventType = xpp.getEventType();
                while (eventType != XmlPullParser.END_DOCUMENT)
                {
                    // Found a start tag
                    if(eventType == XmlPullParser.START_TAG)
                    {
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("channel"))
                        {
                            dataList  = new LinkedList<>();
                        }
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("item"))
                        {
                            data = new TrafficData();
                        }
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("title") && data != null)
                        {
                            // Now just get the associated text
                            String temp = xpp.nextText();
                            // Do something with text
                            data.setTitle(temp);
                        }
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("description") && data != null)
                        {
                            // Now just get the associated text
                            String temp = xpp.nextText();
                            // Do something with text
                            String startDate = data.extractStartDateWithDay(temp);
                            String endDate = data.extractEndDateWithDay(temp);
                            data.setStartDate(startDate);
                            data.setEndDate(endDate);
                        }
                        // Check which Tag we have
                        if (xpp.getName().equalsIgnoreCase("point") && data != null)
                        {
                            // Now just get the associated text
                            String temp = xpp.nextText();
                            // Do something with text
                            double latitude = data.extractLatitude(temp);
                            double longitude = data.extractLongitude(temp);
                            data.setLatitude(latitude);
                            data.setLongitude(longitude);
                        }
                    }
                    else
                    if(eventType == XmlPullParser.END_TAG)
                    {
                        if (xpp.getName().equalsIgnoreCase("item"))
                        {
                            dataList.add(data);
                        }
                    }
                    // Get the next event
                    eventType = xpp.next();
                } // End of while
            }
            catch (XmlPullParserException | IOException e)
            {
                e.printStackTrace();
            }
            return dataList;
        }

    }

}